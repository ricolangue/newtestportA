start https://www.minifier.org/
