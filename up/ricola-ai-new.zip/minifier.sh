start https://www.toptal.com/developers/cssminifier
start https://www.toptal.com/developers/javascript-minifier