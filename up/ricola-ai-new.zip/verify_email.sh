#!/bin/bash 
#Email Verification
start https://mailbite.io/?gad_source=1&gclid=Cj0KCQjwjY64BhCaARIsAIfc7Ya6EjBXaZZJa8LeKjwqvnLd9H8XgqFub3K2ICBM0jd0IATPQqtW-uEaAjXSEALw_wcB
start https://verifalia.com/validate-email/
start https://www.verifyemailaddress.org/email-validation
start https://www.site24x7.com/tools/email-validator.html
start https://quickemailverification.com/tools/email-checker
start https://wiza.co/verify-email-free
start https://mxtoolbox.com/SuperTool.aspx?action=mx%3agmail.com&run=toolpage
start https://www.zerobounce.net/members/signin
start https://emaillistverify.com/
start https://who.is/dns/evidentmn.com
start https://whoishostingthis.com/ 
#recaptcha 
start https://www.google.com/recaptcha/admin/create